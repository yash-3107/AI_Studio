(function() {
    'use strict';

    var myElement21 = document.getElementById('teams-nav');
    new SimpleBar(myElement21, { autoHide: true });

})();