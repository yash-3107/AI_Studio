(function() {
    "use strict"
    
    // for personal information language
    const multipleCancelButton = new Choices(
        '#keywords',
        {
            allowHTML: true,
            removeItemButton: true,
        }
    );
     
})();