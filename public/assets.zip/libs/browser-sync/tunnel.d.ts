declare function _exports(bs: import("./browser-sync"), cb: Function): void;
export = _exports;
