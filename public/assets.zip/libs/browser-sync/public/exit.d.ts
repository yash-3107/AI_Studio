declare function _exports(browserSync: import("../browser-sync")): Function;
export = _exports;
