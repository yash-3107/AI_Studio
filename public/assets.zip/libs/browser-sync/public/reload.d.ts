declare function _exports(emitter: any): Function;
export = _exports;
