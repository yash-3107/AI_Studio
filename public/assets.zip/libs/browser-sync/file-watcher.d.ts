export function plugin(bs: any): any | ((this: typeof import("./file-watcher")) => any);
declare namespace ___Users_shaneosbourne_WebstormProjects_browser_sync_packages_browser_sync_lib_file_watcher_ { }
/**
 * @param patterns
 * @param opts
 * @param cb
 * @returns {*}
 */
export function watch(patterns: any, opts: any, cb: any): any;
export {};
