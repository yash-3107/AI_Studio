declare function _exports(args: any): {
    config: {};
    cb: any;
};
export = _exports;
