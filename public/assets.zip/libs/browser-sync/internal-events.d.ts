export default function internalEvents(bs: any): void;
