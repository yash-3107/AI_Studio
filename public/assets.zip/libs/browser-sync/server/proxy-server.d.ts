declare function _exports(bs: import("../browser-sync")): any;
export = _exports;
