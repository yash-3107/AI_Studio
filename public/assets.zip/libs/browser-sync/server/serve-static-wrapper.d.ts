export default function (): any;
