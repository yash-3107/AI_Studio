declare function _exports(opts: any): void;
export = _exports;
