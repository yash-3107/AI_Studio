declare function _exports(opts: any): any;
export = _exports;
