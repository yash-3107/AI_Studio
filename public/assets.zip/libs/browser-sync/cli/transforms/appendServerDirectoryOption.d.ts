import { BsTempOptions, TransformResult } from "../cli-options";
export declare function appendServerDirectoryOption(incoming: BsTempOptions): TransformResult;
