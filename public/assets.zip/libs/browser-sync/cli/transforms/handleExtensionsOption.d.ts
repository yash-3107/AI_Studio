import { BsTempOptions, TransformResult } from "../cli-options";
export declare function handleExtensionsOption(incoming: BsTempOptions): TransformResult;
