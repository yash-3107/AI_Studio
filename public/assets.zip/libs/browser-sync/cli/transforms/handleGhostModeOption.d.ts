import { BsTempOptions, TransformResult } from "../cli-options";
export declare function handleGhostModeOption(incoming: BsTempOptions): TransformResult;
