import { BsTempOptions, TransformResult } from "../cli-options";
export declare function handleHostOption(incoming: BsTempOptions): TransformResult;
