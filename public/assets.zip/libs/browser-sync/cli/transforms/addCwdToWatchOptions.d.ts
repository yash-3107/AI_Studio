import { BsTempOptions, TransformResult } from "../cli-options";
export declare function addCwdToWatchOptions(incoming: BsTempOptions): TransformResult;
