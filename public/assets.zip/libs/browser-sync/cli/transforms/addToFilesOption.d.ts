import { BsTempOptions, TransformResult } from "../cli-options";
export declare function addToFilesOption(incoming: BsTempOptions): TransformResult;
