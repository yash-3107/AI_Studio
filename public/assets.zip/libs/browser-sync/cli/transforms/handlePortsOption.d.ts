import { BsTempOptions, TransformResult } from "../cli-options";
export declare function handlePortsOption(incoming: BsTempOptions): TransformResult;
