import { BsTempOptions, TransformResult } from "../cli-options";
export declare function handleProxyOption(incoming: BsTempOptions): TransformResult;
