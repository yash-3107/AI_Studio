import { BsTempOptions, TransformResult } from "../cli-options";
export declare function handleServerOption(incoming: BsTempOptions): TransformResult;
