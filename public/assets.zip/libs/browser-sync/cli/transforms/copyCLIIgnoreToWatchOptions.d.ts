import { BsTempOptions, TransformResult } from "../cli-options";
export declare function copyCLIIgnoreToWatchOptions(incoming: BsTempOptions): TransformResult;
