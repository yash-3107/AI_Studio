import { BsTempOptions, TransformResult } from "../cli-options";
export declare function appendServerIndexOption(incoming: BsTempOptions): TransformResult;
