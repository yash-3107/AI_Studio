export function getVersion(pjson: any): string;
export function getConfigFile(filePath: any): any;
export function makeConfig(cwd: any, cb: any): void;
